### R code from vignette source 'ReolUserManual.rnw'

###################################################
### code chunk number 1: ReolUserManual.rnw:11-12
###################################################
options(width=60)


###################################################
### code chunk number 2: ReolUserManual.rnw:27-29
###################################################
library(Reol)
PingAPI()


###################################################
### code chunk number 3: ReolUserManual.rnw:35-37
###################################################
GreatApes <- c("Pongo pygmaeus", "Pongo abelii", "Gorilla gorilla", "Gorilla beringei", "Homo sapiens", "Pan troglodytes", "Pan paniscus")
DownloadedApes <- DownloadSearchedTaxa(GreatApes, , verbose=F)


###################################################
### code chunk number 4: ReolUserManual.rnw:42-44
###################################################
DownloadedApes
MyEOLs <- DownloadedApes[,4]


###################################################
### code chunk number 5: ReolUserManual.rnw:53-54
###################################################
GetRichnessScores(MyEOLs)


###################################################
### code chunk number 6: ReolUserManual.rnw:60-63
###################################################
DataObjectInfo <- CombineDataObjectInformation(MyEOLs, verbose=F)
DataObjectInfo[1,]
DataObjectOverview(MyEOLs, verbose=F)


###################################################
### code chunk number 7: ReolUserManual.rnw:69-70
###################################################
GetCommonNames(MyEOLs, output="c")


###################################################
### code chunk number 8: ReolUserManual.rnw:76-78
###################################################
GetReferences(MyEOLs[1], output="d")[1,]
GetReferences(MyEOLs, output="c")


###################################################
### code chunk number 9: ReolUserManual.rnw:84-86
###################################################
GatherProviderDataFrame(MyEOLs)
BestProvider(MyEOLs)


###################################################
### code chunk number 10: ReolUserManual.rnw:92-93
###################################################
NCBIfiles <- DownloadHierarchy(MyEOLs, database="NCBI Taxonomy", verbose=F)


###################################################
### code chunk number 11: ReolUserManual.rnw:102-104
###################################################
GatherSynonyms(NCBIfiles, "d")
GatherSynonyms(NCBIfiles, "c")


###################################################
### code chunk number 12: ReolUserManual.rnw:113-115
###################################################
ApeTree <- MakeHierarchyTree(NCBIfiles, includeNodeLabels = TRUE)
plot(ApeTree, "p", show.node.label=TRUE, adj=0.5, font=4, edge.width=3, edge.color="dark gray", tip.color="black")


###################################################
### code chunk number 13: ReolUserManual.rnw:122-125
###################################################
edges <- MakeEdgeLabels(NCBIfiles)
plot(ApeTree, "c", show.node.label=FALSE)
edgelabels(text=names(edges), edge=edges, bg="light gray")


###################################################
### code chunk number 14: ReolUserManual.rnw:132-138
###################################################
CNs <- GetCommonNames(MyEOLs, output="c")
plot(ApeTree, label.offset=0.5, x.lim=10, no.margin=TRUE)
edgelabels(text=names(edges), edge=edges, bg="light blue")
trans <- CNs[,3]/10
tiplabels(pch=22, bg=rgb(0,0.5,0.5,trans), cex=2.8, adj=0.7)
tiplabels(CNs[,3], 1:7, frame="none", bg="clear",adj=-1)


